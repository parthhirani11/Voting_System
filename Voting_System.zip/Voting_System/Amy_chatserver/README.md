// module voting_system::voting {

//     use std::signer;
//     use std::vector;
//     use std::error;
//     use std::string;
//     use std::option::{Self, Option};
//     use aptos_framework::account;
//     use aptos_framework::timestamp;
//     use aptos_framework::event::{Self, EventHandle};
//     use aptos_std::type_info::{Self, TypeInfo};
//     use aptos_std::table::{Self, Table};
    
//     const EPROPOSAL_ERROR: u64 = 1;
//     const EPROPOSAL_EMPTY_EXECUTION_HASH: u64 = 2;
    

//     const PROPOSAL_STATE_PENDING: u64 = 0;
//     const PROPOSAL_STATE_SUCCEEDED: u64 = 1;
//     const PROPOSAL_STATE_FAILED: u64 = 3;
// //...............................................................

//     struct Proposal<ProposalType: store> has store {
//         voter_acc_add: address,
//         yes_votes: u128,
//         no_votes: u128,
//         start_time: u64,
//         is_end: bool,
//         end_time: u64,
//         execution_content: Option<ProposalType>,
//         execution_hash: vector<u8>,
//         min_vote_threshold: u128,
//         expiration_time: u64,
//         early_resolution_vote_threshold: Option<u128>,
       
//     }

//     struct CreateProposalEvent has drop, store {
//         proposal_id: u64,
//         early_resolution_vote_threshold: Option<u128>,
//         execution_hash: vector<u8>,
//         expiration_time: u64,
//         min_vote_threshold: u128,
//     }

//     struct RegisterForumEvent has drop, store {
//         name: string::String,
//         hosting_account: address,
//         proposal_type_info: TypeInfo,
//     }

//     struct VotingEvents has store {
//         create_proposal_events: EventHandle<CreateProposalEvent>,
//         register_forum_events: EventHandle<RegisterForumEvent>,
//         vote_events: EventHandle<VoteEvent>,
//     }
//     struct VotingForm<ProposalType: store> has key {
        
//         proposals: Table<u64, Proposal<ProposalType>>,
//         events: VotingEvents,
//         next_proposal_id: u64,
//     }

//     struct VoteEvent has drop, store {
//         proposal_id: u64,
//         num_votes: u64,
//     }

//     struct ResolveProposal has drop, store {
//         proposal_id: u64,
//         yes_votes: u128,
//         no_votes: u128,
       
       
//     }
// //.............................................................................................

// public entry fun register<ProposalType: store>(account: &signer,name: string::String) {
//         let addr = signer::address_of(account);
//         assert!(!exists<VotingForm<ProposalType>>(addr), error::already_exists(EPROPOSAL_ERROR));

//         let voting_form = VotingForm<ProposalType> {
//             next_proposal_id: 0,
//             proposals: table::new<u64, Proposal<ProposalType>>(),
//             events: VotingEvents {
//                 create_proposal_events: account::new_event_handle<CreateProposalEvent>(account),
//                 register_forum_events: account::new_event_handle<RegisterForumEvent>(account),
//                 vote_events: account::new_event_handle<VoteEvent>(account),
//             }
//         };
//         event::emit_event<RegisterForumEvent>(
//             &mut voting_form.events.register_forum_events,
//             RegisterForumEvent {
//                 name,
//                 hosting_account: addr,
//                 proposal_type_info: type_info::type_of<ProposalType>(),
//             },
//         );
//         move_to(account, voting_form);
//     }


// #[view]
// public fun create_proposal<ProposalType: store>(
//         voter_acc_add: address,
//         voting_form_address: address,
//         execution_content: ProposalType,
//         execution_hash: vector<u8>,
//         min_vote_threshold: u128,
//         expiration_time: u64,
//         early_resolution_vote_threshold: Option<u128>,
       
//     ):u64 acquires VotingForm {
//         create_proposal_v2(
//             voter_acc_add,
//             voting_form_address,
//             execution_content,
//             execution_hash,
//             min_vote_threshold,
//             expiration_time,
//             early_resolution_vote_threshold,

//         )
//     }
   
// public fun create_proposal_v2<ProposalType: store>(
//             voter_acc_add: address,
//             voting_form_address: address,
//             execution_content: ProposalType,
//             execution_hash: vector<u8>,
//             min_vote_threshold: u128,
//             expiration_time: u64,
//             early_resolution_vote_threshold: Option<u128>,
          
//         ):u64 acquires VotingForm {
//             if (option::is_some(&early_resolution_vote_threshold)) {
//                 assert!(
//                     min_vote_threshold <= *option::borrow(&early_resolution_vote_threshold),
//                     error::invalid_argument(EPROPOSAL_ERROR),
//                 );
//             };
        
//         assert!(vector::length(&execution_hash) > 0, error::invalid_argument(EPROPOSAL_EMPTY_EXECUTION_HASH));

//         let voting_form = borrow_global_mut<VotingForm<ProposalType>>(voting_form_address);
//         let proposal_id = voting_form.next_proposal_id;
//         voting_form.next_proposal_id = voting_form.next_proposal_id + 1;

//         table::add(&mut voting_form.proposals, proposal_id, Proposal {
//             voter_acc_add,
//             start_time: timestamp::now_seconds(),
//             execution_content: option::some<ProposalType>(execution_content),
//             execution_hash,
//             min_vote_threshold,
//             expiration_time,
//             early_resolution_vote_threshold,
//             yes_votes: 0,
//             no_votes: 0,
//             is_end: false,
//             end_time: 0,
//         });
//         event::emit_event<CreateProposalEvent>(
//             &mut voting_form.events.create_proposal_events,
//             CreateProposalEvent {
//                 proposal_id,
//                 early_resolution_vote_threshold,
//                 execution_hash,
//                 expiration_time,
//                 min_vote_threshold,
//             },
//         );
//         proposal_id
//     }

// public fun vote<ProposalType: store>(
//         _proof: &ProposalType,
//         voting_form_address: address,
//         proposal_id: u64,
//         num_votes: u64,
//         should_pass: bool,
//     ) acquires VotingForm {
//         let voting_form = borrow_global_mut<VotingForm<ProposalType>>(voting_form_address);
//         let proposal = table::borrow_mut(&mut voting_form.proposals, proposal_id);
//         if (should_pass) {
//             proposal.yes_votes = proposal.yes_votes + (num_votes as u128);
//         } else {
//             proposal.no_votes = proposal.no_votes + (num_votes as u128);
//         };
//         event::emit_event<VoteEvent>(
//             &mut voting_form.events.vote_events,
//             VoteEvent { proposal_id, num_votes },
//         );
//     }
    
// //...................................................................................

// #[view]
// public fun get_proposal_state<ProposalType: store>(
//         voting_form_address: address,
//         proposal_id: u64,
//     ): u64 acquires VotingForm {
//         if (voting_closed<ProposalType>(voting_form_address, proposal_id)) {
//             let voting_form = borrow_global<VotingForm<ProposalType>>(voting_form_address);
//             let proposal = table::borrow(&voting_form.proposals, proposal_id);
//             let yes_votes = proposal.yes_votes;
//             let no_votes = proposal.no_votes;

//             if (yes_votes > no_votes && yes_votes + no_votes >= proposal.min_vote_threshold) {
//                 PROPOSAL_STATE_SUCCEEDED
//             } else {
//                 PROPOSAL_STATE_FAILED
//             }
//         } else {
//             PROPOSAL_STATE_PENDING
//         }
//     }

// #[view]
// public fun voting_closed<ProposalType: store>(voting_form_address: address, proposal_id: u64): bool acquires VotingForm {
//         let voting_form = borrow_global<VotingForm<ProposalType>>(voting_form_address);
//         let proposal = table::borrow(&voting_form.proposals, proposal_id);
//         can_be_resolved_early(proposal) || is_voting_period_over(proposal)
//     }
//     public fun can_be_resolved_early<ProposalType: store>(proposal: &Proposal<ProposalType>): bool {
//         if (option::is_some(&proposal.early_resolution_vote_threshold)) {
//             let early_resolution_threshold = *option::borrow(&proposal.early_resolution_vote_threshold);
//             if (proposal.yes_votes >= early_resolution_threshold || proposal.no_votes >= early_resolution_threshold) {
//                 return true
//             };
//         };
//         false
//     }
//     public fun is_voting_period_over<ProposalType: store>(proposal: &Proposal<ProposalType>): bool {
//         timestamp::now_seconds() > proposal.expiration_time
//     }



// #[view]
// public fun get_execution_hash<ProposalType: store>(
//         voting_form_address: address,
//         proposal_id: u64,
//     ): vector<u8> acquires VotingForm {
//         let voting_forum = borrow_global_mut<VotingForm<ProposalType>>(voting_form_address);
//         let proposal = table::borrow_mut(&mut voting_forum.proposals, proposal_id);
//         proposal.execution_hash
//     }

//  }